$(function(){
  var mixer = mixitup('.portfolio__content');

  $('.blog__slider').slick({
    arrows: false,
    dots: true,
  });

});